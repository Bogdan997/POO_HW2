package ilsterg;


import java.awt.image.*;
import java.io.*;

import javax.imageio.ImageIO;

public class JustCompare {

	public static void main(String[] args, String str, int width, int height) {
		System.out.println(str);
		BufferedImage bi1 = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);
		BufferedImage bi2 = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);
		BufferedImage bi3 = new BufferedImage(height, width, BufferedImage.TYPE_4BYTE_ABGR);
		try {
			bi1 = ImageIO.read(new File("drawing.png"));
			bi2 = ImageIO.read(new File(str));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		int a, b, nrOfSame = 0, nrOfPixels = 0, maxPerLine, maxOfMax = 0;
		for ( int i = 0; i < width; i ++ ) {
			maxPerLine = 0;
			for ( int j = 0; j < height; j ++ ) {
				a = bi1.getRGB(j, i);
				b = bi2.getRGB(j, i);
				if ( a == b ) {
					nrOfSame ++;
					//bi3.setRGB(j, i, Color.WHITE.hashCode());
				}
				else {
					bi3.setRGB(j, i, bi2.getRGB(j, i));
					maxPerLine ++;
				}
				nrOfPixels ++;
			}
			if(maxOfMax < maxPerLine) {
				maxOfMax = maxPerLine; //dupa ce repar LINIA 0, dar oricum stas90faf0inhwg09qain
			}
		}
		
		System.out.println(nrOfSame + " of " + nrOfPixels);
		System.out.println("maxDifferencesPerLine:" + maxOfMax);
		try {
			ImageIO.write(bi3, "png", new File("CorrectDifYours.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
