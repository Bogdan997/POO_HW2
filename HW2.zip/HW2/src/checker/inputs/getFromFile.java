package inputs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import java.io.File;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.awt.Color;
import java.io.*;
import main.*;
import support.Canvas;

public class getFromFile {
	public getFromFile () {}
	
	String fileName;
	public static int placeAfter;

	public getFromFile(String fileName) {
		this.fileName = fileName;
	}
	
	public String readWord (String line, int position) {
		char spaceOrNot = line.charAt(position);
		String word = "";
		while ( spaceOrNot == 32 && position < line.length() ) {
			spaceOrNot = line.charAt(++position);
		}
		if ( position < line.length() ) {
			word = String.valueOf(spaceOrNot);
			spaceOrNot = line.charAt(++position);
			while ( spaceOrNot != 32 && spaceOrNot != 13 && spaceOrNot != 10 ) {
				word = word.concat(String.valueOf(spaceOrNot));
				spaceOrNot = line.charAt(++position);
			}
		}
		placeAfter += word.length() + 1;
		return word;
	}
	
	public int readInt (String line, int position, boolean isColor) {
		line = line.concat(String.valueOf((char)13));
		int NO = 0;
		if ( isColor == false ) {
			char spaceOrNot = line.charAt(position);
			while ( spaceOrNot == 32 && position < line.length() ) {
				spaceOrNot = line.charAt(++position);
				placeAfter ++;
			}
			while ( line.charAt(position) > 32 ) { // (!=13 && !=32)
				NO *= 10;
				NO += line.charAt(position++) - 48;
				placeAfter++;
			}
		}
		else {
			position++;
			placeAfter ++;
			char spaceOrNot = line.charAt(position);
			while ( spaceOrNot == 32 && position < line.length() ) {
				spaceOrNot = line.charAt(++position);
			}
			
			position++;
			placeAfter ++;
			if ( spaceOrNot > 32 ) {
				int R, G, B, A;
				String theColor = line.substring(position, position + 6);
				int[] numbers = new int[6];
				for ( int i = 0; i < theColor.length(); i ++ ) {
					numbers[i] = theColor.charAt(i);
					if ( theColor.charAt(i) >= 58 )
						numbers[i] -= 7;
				}
				R = 16 * (numbers[0] - 48) + numbers[1] - 48;
				G = 16 * (numbers[2] - 48) + numbers[3] - 48;
				B = 16 * (numbers[4] - 48) + numbers[5] - 48;
				//System.out.println(R + " " + G + " " + B);
				
				position += 6;
				placeAfter += 6;
				spaceOrNot = line.charAt(position);
				while ( spaceOrNot == 32 && position < line.length() ) {
					spaceOrNot = line.charAt(++position);
					placeAfter ++;
				}
				if ( spaceOrNot > 32 ) {
					A = readInt(line, position, false);
					NO = (new Color(R, G, B, A)).hashCode();
				}
			}
		}
		return NO;
	}
	
	/*public int numberDigitsOfLastNumber (int lastNumber) {
		if ( lastNumber == 0 )
			return 1;
		
		int numberDigits = 1;
		while ( lastNumber / 10 != 0 )
			numberDigits ++;
		return numberDigits;
	}*/
	
	ArrayList<Visitable> Figures;
	
	public ArrayList<Visitable> readsInfo() {
		int NO;
		Figures = new ArrayList<Visitable>();
		
		try {
			FileReader fIn = new FileReader(fileName);
			BufferedReader scanner = new BufferedReader(fIn);
			
			NO = readInt(scanner.readLine(), 0, false);
			placeAfter = 0;
			String firstLine = scanner.readLine();
			String canvasCall = readWord(firstLine, 0);
			if ( canvasCall.equals("CANVAS")) {
				support.Canvas.height = readInt(firstLine, placeAfter, false);
				support.Canvas.width = readInt(firstLine, placeAfter, false);
				support.Canvas.hashClr = readInt(firstLine, placeAfter, true);
				//support.Canvas.hashClr = (new Color(255,0,0,100)).hashCode();
			}
			
			Figures = new ArrayList<Visitable>();
			for ( int shapeNo = 0; shapeNo < NO - 1; shapeNo ++ ) {
				placeAfter = 0;
				String specificLine = scanner.readLine();
				Figures.add((new main.getShape(specificLine)).getAttributes());
				//VIZITABLE->VISITOR
			}
			scanner.close();
			
		}
		catch (FileNotFoundException e) {
			System.out.println("Opening file error.");
		}
		catch (IOException e) {
			System.out.println("Undetected error.");
		}
		
		return Figures;
	}
	
	public void outputsShapes (ArrayList<Visitable> Figures) {
		BufferedImage image = new BufferedImage(support.Canvas.width, support.Canvas.height, BufferedImage.TYPE_4BYTE_ABGR);
		
		Canvas.computeCanvas(image);
		Visitor toDraw = new Visitor(image);
		for ( Visitable form : Figures ) {
			form.accept(toDraw);
		}
		System.out.println("size" + Figures.size());
		try {
			ImageIO.write(image, "png", new File("drawing.png"));
		}
		catch (IOException e) {
			System.out.println("Output error.");
		}
	}
	
}
