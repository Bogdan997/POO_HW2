package support;

import java.awt.image.BufferedImage;

public class Canvas {
	public static int hashClr;
	public static int height = 0, width = 0;

	public Canvas(int Height, int Width, int HashClr) {
		super();
		height = Height;
		width = Width;
		hashClr = HashClr;
	}
	
	public static void computeCanvas (BufferedImage img) {
		for ( int i = 0; i < height; i ++ ) {
			for ( int j = 0; j < width; j ++ ) {
				img.setRGB(j, i, hashClr);
			}
		}
	}
	
	public boolean notExceeded () {
		return true;
	}
}