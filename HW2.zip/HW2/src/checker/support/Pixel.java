package support;

public class Pixel {
	public Position pos;
	public int fillNearby;
	
	public Pixel(Position pos, int fillNearby) {
		this.pos = pos;
		this.fillNearby = fillNearby;
	}
}
