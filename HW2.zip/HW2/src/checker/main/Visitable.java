package main;

public interface Visitable {
	public void accept (Draw specificShape);
}
