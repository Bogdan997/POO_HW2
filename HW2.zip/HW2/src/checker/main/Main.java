package main;

import java.util.Scanner;
import inputs.getFromFile;

public class Main {

	public static void main(String[] args) {
		getFromFile shapeInfo = new getFromFile(args[0]);
		shapeInfo.outputsShapes(shapeInfo.readsInfo());
		/*Scanner scanner = new Scanner(System.in);
		String strArg1 = scanner.next();
		scanner.close(); 
		JustCompare.main(null, args[1], support.Canvas.height, support.Canvas.width);*/
	}

}
