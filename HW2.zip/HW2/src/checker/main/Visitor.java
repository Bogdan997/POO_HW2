package main;

import java.awt.image.BufferedImage;
import java.awt.Color;
import shapes.*;
import support.Canvas;

public class Visitor implements Draw {
	BufferedImage img;
	public Visitor (BufferedImage img) {
		this.img = img;
	}
	
	shapes.Line.distanceFromCenter nw;
	int x;
	int y;
	int s1;
	int s2;
	boolean interchanged;
	int error;
	
	/*int sign (int a) {
		if (a < 0)
			return -1;
		else if (a > 0)
			return 1;
		return 0;
	}
	
	void interchange (distanceFromCenter nw) {
		int i;
		i = nw.delta_x;
		nw.delta_x = nw.delta_y;
		nw.delta_y = i;
	}*/
	
	@Override
	public void draw(Line line) {
		
		nw = new shapes.Line.distanceFromCenter();
		x = line.xi;
		y = line.yi;
		nw.delta_x = Math.abs(line.xf - line.xi);
		nw.delta_y = Math.abs(line.yf - line.yi);
		s1 = Line.sign(line.xf - line.xi);
		s2 = Line.sign(line.yf - line.yi);
		if ( nw.delta_y > nw.delta_x ) {
			Line.interchange(nw);
			interchanged = true;
		}
		else {
			interchanged = false;
		}
		error = 2 * nw.delta_y - nw.delta_x;
		
		for ( int i = 0; i <= nw.delta_x; i ++ ) { //INFPOS
			if ( (x >= 0 && x < Canvas.width) && (y >= 0 && y < Canvas.height) ) {
				img.setRGB(x, y, line.hashColor);
			}
			while ( error > 0) {
				if ( interchanged == true ) {
					x += s1;
				}
				else {
					y += s2;
				}
				error -= 2 * nw.delta_x;
			}
			
			if ( interchanged == true ) {
				y += s2;
			}
			else {
				x += s1;
			}
			
			error += 2 * nw.delta_y;
		}
	}
	
	int l, hashClr1, hashClr2;

	@Override
	public void draw(Square square) {
		x = square.x;
		x0 = square.x;
		y = square.y;
		y0 = square.y;
		l = square.l;
		hashClr1 = square.hashClr1;
		hashClr2 = square.hashClr2;
		draw(new Line(x, y, x + l, y, hashClr1));
		x = x0; y = y0;
		draw(new Line(x + l, y, x + l, y + l, hashClr1));
		x = x0; y = y0;
		draw(new Line(x + l, y + l, x, y + l, hashClr1));
		x = x0; y = y0;
		draw(new Line(x, y + l, x, y, hashClr1));
		(new shapes.Square(x0, y0, l, hashClr1, hashClr2)).floodFill(img);
	}
	
	int H, L;

	@Override
	public void draw(Rectangle rectangle) {
		x = rectangle.x;
		x0 = rectangle.x;
		y = rectangle.y;
		y0 = rectangle.y;
		L = rectangle.L;
		H = rectangle.H;
		hashClr1 = rectangle.hashClr1;
		hashClr2 = rectangle.hashClr2;
		draw(new Line(x, y, x + L, y, hashClr1));
		x = x0; y = y0;
		draw(new Line(x + L, y, x + L, y + H, hashClr1));
		x = x0; y = y0;
		draw(new Line(x + L, y + H, x, y + H, hashClr1));
		x = x0; y = y0;
		draw(new Line(x, y + H, x, y, hashClr1));
		(new shapes.Rectangle(x0, y0, H, L, hashClr1, hashClr2)).floodFill(img);
	}

	int xc0, xc, yc0, yc, R;
	@Override
	public void draw(Circle circle) {
		hashClr1 = circle.hashClr1;
		Color ghostColor = new Color(0, 0, 0, 101);
		Draw1(circle, true, ghostColor.hashCode());
		Draw1(circle, false, hashClr1);
	}
	public void Draw1(Circle circle, boolean firstAppeal, int hashClr1) {
		xc0 = circle.xc;
		xc = circle.xc;
		yc0 = circle.yc;
		yc = circle.yc;
		R = circle.R;
		hashClr2 = circle.hashClr2;
		(new shapes.Circle(xc, yc, R, hashClr1, hashClr2)).bresenham_alg(img);
		System.out.println("xcyc: " + xc + " " + yc);
		xc = xc0; yc = yc0;
		System.out.println("xcyc: " + xc + " " + yc);
		if(firstAppeal) {
			(new shapes.Circle(xc, yc, R, hashClr1, hashClr2)).floodFill(img);
		}
	}

	int x1, y1, x2, y2, x3, y3, x10, y10, x20, y20, x30, y30;
	@Override
	public void draw(Triangle triangle) {
		x1 = triangle.x1; x10 = triangle.x1;
		x2 = triangle.x2; x20 = triangle.x2;
		x3 = triangle.x3; x30 = triangle.x3;
		y1 = triangle.y1; y10 = triangle.y1;
		y2 = triangle.y2; y20 = triangle.y2;
		y3 = triangle.y3; y30 = triangle.y3;
		System.out.println("dar acum??? " + triangle.hashClr2);
		draw(new Line(x1, y1, x2, y2, triangle.hashClr1));
		x1 = x10;
		x2 = x20;
		x3 = x30;
		y1 = y10;
		y2 = y20;
		y3 = y30;
		draw(new Line(x2, y2, x3, y3, triangle.hashClr1));
		x1 = x10;
		x2 = x20;
		x3 = x30;
		y1 = y10;
		y2 = y20;
		y3 = y30;
		draw(new Line(x3, y3, x1, y1, triangle.hashClr1));
		x1 = x10;
		x2 = x20;
		x3 = x30;
		y1 = y10;
		y2 = y20;
		y3 = y30;
		System.out.println("hehehe " + triangle.hashClr1 + " [][] " + triangle.hashClr2 + " " + hashClr2);
		(new shapes.Triangle(x1, y1, x2, y2, x3, y3, triangle.hashClr1, triangle.hashClr2)).floodFill(img);
	}

	int x0, y0, diagHoriz, diagVert;
	@Override
	public void draw(Diamond diamond) {
		x0 = diamond.x;
		y0 = diamond.y;
		diagHoriz = diamond.diagHoriz;
		diagVert = diamond.diagVert;
		hashClr1 = diamond.hashClr1;
		hashClr2 = diamond.hashClr2;
		int diagHorizDiv2 = (int) Math.floor((float)diagHoriz / 2);
		int diagVertDiv2 = (int) Math.floor((float)diagVert / 2);
		
		support.Position pU = new support.Position();
		support.Position pD = new support.Position();
		support.Position pL = new support.Position();
		support.Position pR = new support.Position();
		
		pU.x = x0;
		pU.y = y0 + diagVertDiv2;
		pD.x = x0;
		pD.y = y0 - diagVertDiv2;
		pL.x = x0 - diagHorizDiv2;
		pL.y = y0;
		pR.x = x0 + diagHorizDiv2;
		pR.y = y0;
		draw(new Line(pU.x, pU.y, pR.x, pR.y, hashClr1));
		draw(new Line(pR.x, pR.y, pD.x, pD.y, hashClr1));
		draw(new Line(pD.x, pD.y, pL.x, pL.y, hashClr1));
		draw(new Line(pL.x, pL.y, pU.x, pU.y, hashClr1));
		(new shapes.Diamond(x0, y0, diagHoriz, diagVert, hashClr1, hashClr2)).floodFill(img);
	}

	int nrVrtx;
	support.Position[] Vrtx;
	@Override
	public void draw(Polygon polygon) {
		nrVrtx = polygon.nrVrtx;
		Vrtx = polygon.Vrtx;
		hashClr1 = polygon.hashClr1;
		hashClr2 = polygon.hashClr2;

		for ( int i = 0; i < nrVrtx - 1; i ++ ) {
			draw(new Line(Vrtx[i].x, Vrtx[i].y, Vrtx[i + 1].x, Vrtx[i + 1].y, hashClr1));
		}
		draw(new Line(Vrtx[nrVrtx - 1].x, Vrtx[nrVrtx - 1].y, Vrtx[0].x, Vrtx[0].y, hashClr1));
		
		(new shapes.Polygon(nrVrtx, Vrtx, hashClr1, hashClr2)).floodFill(img);
	}
	
}
