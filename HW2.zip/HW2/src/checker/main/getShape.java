package main;

import shapes.*;
import support.Position;
import inputs.getFromFile;

public class getShape {
	String line;

	public getShape(String line) {
		this.line = line;
	}
	
	public String getType () {
		return (new getFromFile()).readWord(line, 0);
	}
	
	public Visitable getAttributes () {
		switch (getType()) {
			case "LINE" :
				return assignLine();
			case "SQUARE" :
				return assignSquare();
			case "RECTANGLE" :
				return assignRectangle();
			case "CIRCLE" :
				return assignCircle();
			case "TRIANGLE" :
				return assignTriangle();
			case "DIAMOND" :
				return assignDiamond();
			case "POLYGON" :
				return assignPolygon();
			default :
				return null;
		}
	}
	
	public Line assignLine() {
		int xi, yi, xf, yf;
		int hashColor;
		getFromFile get = new getFromFile();
		xi = get.readInt(line, getFromFile.placeAfter, false);
		yi = get.readInt(line, getFromFile.placeAfter, false);
		xf = get.readInt(line, getFromFile.placeAfter, false);
		yf = get.readInt(line, getFromFile.placeAfter, false);
		hashColor = get.readInt(line, getFromFile.placeAfter, true);
		return new Line(xi, yi, xf, yf, hashColor);
	}
	
	public Square assignSquare() {
		int x, y, l, hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		x = get.readInt(line, getFromFile.placeAfter, false);
		y = get.readInt(line, getFromFile.placeAfter, false);
		l = get.readInt(line, getFromFile.placeAfter, false);
		l --;
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Square(x, y, l, hashClr1, hashClr2);
	}
	
	public Rectangle assignRectangle() {
		int x, y, H, L, hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		x = get.readInt(line, getFromFile.placeAfter, false);
		y = get.readInt(line, getFromFile.placeAfter, false);
		H = get.readInt(line, getFromFile.placeAfter, false);
		L = get.readInt(line, getFromFile.placeAfter, false);
		L --; H --;
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Rectangle(x, y, H, L, hashClr1, hashClr2);
	}
	
	public Circle assignCircle() {
		int xc, yc, R;
		int hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		xc = get.readInt(line, getFromFile.placeAfter, false);
		yc = get.readInt(line, getFromFile.placeAfter, false);
		R = get.readInt(line, getFromFile.placeAfter, false);
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Circle(xc, yc, R, hashClr1, hashClr2);
	}
	
	public Triangle assignTriangle() {
		int x1, y1, x2, y2, x3, y3, hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		x1 = get.readInt(line, getFromFile.placeAfter, false);
		y1 = get.readInt(line, getFromFile.placeAfter, false);
		x2 = get.readInt(line, getFromFile.placeAfter, false);
		y2 = get.readInt(line, getFromFile.placeAfter, false);
		x3 = get.readInt(line, getFromFile.placeAfter, false);
		y3 = get.readInt(line, getFromFile.placeAfter, false);
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Triangle(x1, y1, x2, y2, x3, y3, hashClr1, hashClr2);
	}
	
	public Diamond assignDiamond() {
		int x, y, diagHoriz, diagVert, hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		x = get.readInt(line, getFromFile.placeAfter, false);
		y = get.readInt(line, getFromFile.placeAfter, false);
		diagHoriz = get.readInt(line, getFromFile.placeAfter, false);
		diagVert = get.readInt(line, getFromFile.placeAfter, false);
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Diamond(x, y, diagHoriz, diagVert, hashClr1, hashClr2);
	}
	
	public Polygon assignPolygon() {
		int nrVrtx, hashClr1, hashClr2;
		getFromFile get = new getFromFile();
		nrVrtx = get.readInt(line, getFromFile.placeAfter, false);
		Position[] Vrtx = new Position[nrVrtx];
		for (int i = 0; i < nrVrtx; i ++ ) {
			Vrtx[i] = new Position();
			Vrtx[i].x = get.readInt(line, getFromFile.placeAfter, false);
			Vrtx[i].y = get.readInt(line, getFromFile.placeAfter, false);
		}
		hashClr1 = get.readInt(line, getFromFile.placeAfter, true);
		hashClr2 = get.readInt(line, getFromFile.placeAfter, true);
		return new Polygon(nrVrtx, Vrtx, hashClr1, hashClr2);
	}
	
}
