package shapes;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import main.Visitable;

import main.Draw;
import support.*;

public class Diamond implements Visitable {
	public int x, y, diagHoriz, diagVert, hashClr1, hashClr2;
	
	Position pU, pD, pL, pR;
	
	public Diamond(int x, int y, int diagHoriz, int diagVert, int hashClr1, int hashClr2) {
		super();
		this.x = x;
		this.y = y;
		this.diagHoriz = diagHoriz;
		this.diagVert = diagVert;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
		int diagHorizDiv2 = Math.round((float)diagHoriz / 2);
		int diagVertDiv2 = Math.round((float)diagVert / 2);
		
		
		pU = new Position();
		pD = new Position();
		pL = new Position();
		pR = new Position();
		
		pU.x = x;
		pU.y = y + diagVertDiv2;
		pD.x = x;
		pD.y = y - diagVertDiv2;
		pL.x = x - diagHorizDiv2;
		pL.y = y;
		pR.x = x + diagHorizDiv2;
		pR.y = y;
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*public void draw (BufferedImage img) {
		(new Line(pU.x, pU.y, pR.x, pR.y, hashClr1)).draw(img);
		(new Line(pR.x, pR.y, pD.x, pD.y, hashClr1)).draw(img);
		(new Line(pD.x, pD.y, pL.x, pL.y, hashClr1)).draw(img);
		(new Line(pL.x, pL.y, pU.x, pU.y, hashClr1)).draw(img);
		floodFill(img);
	}*/

	public Position calculateCentroid() {
		return new Position(x, y);
	}
	
	public void floodFill (BufferedImage img) {
		Position centralPos = calculateCentroid();
		int replacementColor = hashClr2, boundColor = hashClr1;
		
		List<Pixel> pixels = new ArrayList<Pixel>();
		pixels.add(new Pixel(centralPos, 4));
		ListIterator<Pixel> it = pixels.listIterator();

		
		while(it.hasNext()) {
			Pixel px = it.next();
			
			img.setRGB(px.pos.x, px.pos.y, replacementColor);
			if ( px.pos.x >= 1 )
			if (img.getRGB(px.pos.x - 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x - 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x - 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y >= 1 )
			if (img.getRGB(px.pos.x, px.pos.y - 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y - 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y - 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.x < Canvas.width - 1)
			if (img.getRGB(px.pos.x + 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x + 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x + 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y < Canvas.height - 1)
			if (img.getRGB(px.pos.x, px.pos.y + 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y + 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y + 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.fillNearby == 0 ) {
				it.previous();
				it.next();
				it.remove();
			}
		}
	}
	
}
