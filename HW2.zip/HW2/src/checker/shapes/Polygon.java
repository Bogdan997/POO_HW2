package shapes;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import main.Visitable;

import main.Draw;
import support.*;

public class Polygon implements Visitable {
	
	public int nrVrtx, hashClr1, hashClr2;
	public Position[] Vrtx;
	
	public Polygon(int nrVrtx, Position[] vrtx, int hashClr1, int hashClr2) {
		super();
		this.nrVrtx = nrVrtx;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
		Vrtx = vrtx;
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*public void draw (BufferedImage img) {
		
		for ( int i = 0; i < nrVrtx - 1; i ++ ) {
			(new Line(Vrtx[i].x, Vrtx[i].y, Vrtx[i + 1].x, Vrtx[i + 1].y, hashClr1)).draw(img);
		}
		(new Line(Vrtx[nrVrtx - 1].x, Vrtx[nrVrtx - 1].y, Vrtx[0].x, Vrtx[0].y, hashClr1)).draw(img);
		
		floodFill(img);
	}*/

	public Position calculateCentroid() {
		float A = 0, Cx = 0, Cy = 0;
		for ( int j = 0; j < nrVrtx - 1; j ++ ) {
			A += Vrtx[j].x * Vrtx[j + 1].y - Vrtx[j + 1].x * Vrtx[j].y;
			Cx += (Vrtx[j].x + Vrtx[j + 1].x) * (Vrtx[j].x * Vrtx[j + 1].y - Vrtx[j + 1].x * Vrtx[j].y);
			Cy += (Vrtx[j].y + Vrtx[j + 1].y) * (Vrtx[j].x * Vrtx[j + 1].y - Vrtx[j + 1].x * Vrtx[j].y);
		}
		A /= 2;
		Cx /= (A * 6);
		Cy /= (A * 6);
		
		return new Position(Math.round(Cx), Math.round(Cy));
	}
	
	public void floodFill (BufferedImage img) {
		Position centralPos = calculateCentroid();
		int replacementColor = hashClr2, boundColor = hashClr1;
		
		List<Pixel> pixels = new ArrayList<Pixel>();
		pixels.add(new Pixel(centralPos, 4));
		ListIterator<Pixel> it = pixels.listIterator();
		System.out.println(replacementColor + " repl");

		
		while(it.hasNext()) {
			Pixel px = it.next();
			
			img.setRGB(px.pos.x, px.pos.y, replacementColor);
			if ( px.pos.x >= 1 )
			if (img.getRGB(px.pos.x - 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x - 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x - 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y >= 1 )
			if (img.getRGB(px.pos.x, px.pos.y - 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y - 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y - 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.x < Canvas.width - 1)
			if (img.getRGB(px.pos.x + 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x + 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x + 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y < Canvas.height - 1)
			if (img.getRGB(px.pos.x, px.pos.y + 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y + 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y + 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.fillNearby == 0 ) {
				it.previous();
				it.next();
				it.remove();
			}
		}
	}
	
}
