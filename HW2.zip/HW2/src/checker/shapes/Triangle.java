package shapes;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import main.Visitable;

import main.Draw;
import support.*;

public class Triangle implements Visitable {
	public int x1, y1, x2, y2, x3, y3, hashClr1, hashClr2;

	public Triangle(int x1, int y1, int x2, int y2, int x3, int y3, int hashClr1, int hashClr2) {
		super();
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.x3 = x3;
		this.y3 = y3;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
	}
	
	public void accept (Draw specificShape) {
		System.out.println("aaaa " + this.hashClr2);
		specificShape.draw(this);
	}
	/*public void draw (BufferedImage img) {
		
		(new Line(x1, y1, x2, y2, hashClr1)).draw(img);
		(new Line(x2, y2, x3, y3, hashClr1)).draw(img);
		(new Line(x3, y3, x1, y1, hashClr1)).draw(img);
		floodFill(img);
		
	}*/

	public Position calculateCentroid() {
		System.out.printf("%d %d\n", (x1 + x2 + x3) / 3, (y1 + y2 + y3) / 3);
		return new Position((x1 + x2 + x3) / 3, (y1 + y2 + y3) / 3);
	}
	
	public void floodFill (BufferedImage img) {
		Position centralPos = calculateCentroid();
		img.setRGB(centralPos.x, centralPos.y, 1);
		int replacementColor = hashClr2, boundColor = hashClr1;
		
		List<Pixel> pixels = new ArrayList<Pixel>();
		pixels.add(new Pixel(centralPos, 4));
		ListIterator<Pixel> it = pixels.listIterator();
		System.out.println(replacementColor + " repl");

		
		while(it.hasNext()) {
			Pixel px = it.next();
			
			img.setRGB(px.pos.x, px.pos.y, replacementColor);
			if ( px.pos.x >= 1 )
			if (img.getRGB(px.pos.x - 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x - 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x - 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y >= 1 )
			if (img.getRGB(px.pos.x, px.pos.y - 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y - 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y - 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.x < Canvas.width - 1)
			if (img.getRGB(px.pos.x + 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x + 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x + 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y < Canvas.height - 1)
			if (img.getRGB(px.pos.x, px.pos.y + 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y + 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y + 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.fillNearby == 0 ) {
				it.previous();
				it.next();
				it.remove();
			}
		}
	}
	
}
