package shapes;

import java.awt.image.BufferedImage;
import main.Draw;
import support.*;
import main.Visitable;

public class Square implements Visitable {
	public int x, y, l, hashClr1, hashClr2;

	public Square(int x, int y, int l, int hashClr1, int hashClr2) {
		super();
		this.x = x;
		this.y = y;
		this.l = l;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*@Override
	public void draw (BufferedImage img) {
		(new Line(x, y, x + l, y, hashClr1)).draw(img);
		(new Line(x + l, y, x + l, y + l, hashClr1)).draw(img);
		(new Line(x + l, y + l, x, y + l, hashClr1)).draw(img);
		(new Line(x, y + l, x, y, hashClr1)).draw(img);
		floodFill(img);
	}*/

	public void floodFill(BufferedImage img) {
		int replacementColor = hashClr2;
		for ( int i = Math.max(y + 1, 0); i < Math.min(y + l, Canvas.height); i ++ ) {
			for ( int j = Math.max(x + 1, 0); j < Math.min(x + l, Canvas.width); j ++ ) {
				img.setRGB(j, i, replacementColor);
			}
		}
	}
}
