package shapes;

import java.awt.image.BufferedImage;

public interface Figure {
	public void draw(BufferedImage img);
}
