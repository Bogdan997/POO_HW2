package shapes;

import main.Visitable;
import main.Draw;

public class Line implements Visitable {
	public int xi, yi, xf, yf;
	public int hashColor;
	public Line(int xi, int yi, int xf, int yf, int hashColor) {
		super();
		this.xi = xi;
		this.yi = yi;
		this.xf = xf;
		this.yf = yf;
		this.hashColor = hashColor;
	}
	
	public static class distanceFromCenter {
		public int delta_x;
		public int delta_y;
	}
	distanceFromCenter nw = new distanceFromCenter();
	int x;
	int y;
	int s1;
	int s2;
	boolean interchanged;
	int error;
	
	static public int sign (int a) {
		if (a < 0)
			return -1;
		else if (a > 0)
			return 1;
		return 0;
	}
	
	static public void interchange (distanceFromCenter nw) {
		int i;
		i = nw.delta_x;
		nw.delta_x = nw.delta_y;
		nw.delta_y = i;
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*@Override
	public void draw (BufferedImage bi) {
		x = xi;
		y = yi;
		nw.delta_x = Math.abs(xf - xi);
		nw.delta_y = Math.abs(yf - yi);
		s1 = sign(xf - xi);
		s2 = sign(yf - yi);
		if ( nw.delta_y > nw.delta_x ) {
			interchange(nw);
			interchanged = true;
		}
		else {
			interchanged = false;
		}
		error = 2 * nw.delta_y - nw.delta_x;
		
		for ( int i = 0; i <= nw.delta_x; i ++ ) { //INFPOS
			if ( (x >= 0 && x < Canvas.width) && (y >= 0 && y < Canvas.height) )
				bi.setRGB(x, y, hashColor);
			
			while ( error > 0) {
				if ( interchanged == true ) {
					x += s1;
				}
				else {
					y += s2;
				}
				error -= 2 * nw.delta_x;
			}
			
			if ( interchanged == true ) {
				y += s2;
			}
			else {
				x += s1;
			}
			
			error += 2 * nw.delta_y;
		}
	}*/
}
