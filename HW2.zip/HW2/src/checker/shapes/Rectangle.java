package shapes;

import java.awt.image.BufferedImage;
import main.Draw;
import support.*;
import main.Visitable;

public class Rectangle implements Visitable {
	public int x, y, H, L, hashClr1, hashClr2;

	public Rectangle(int x, int y, int H, int l2, int hashClr1, int hashClr2) {
		super();
		this.x = x;
		this.y = y;
		this.H = H;
		L = l2;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*@Override
	public void draw (BufferedImage img) {
		(new Line(x, y, x + L, y, hashClr1)).draw(img);
		(new Line(x + L, y, x + L, y + H, hashClr1)).draw(img);
		(new Line(x + L, y + H, x, y + H, hashClr1)).draw(img);
		(new Line(x, y + H, x, y, hashClr1)).draw(img);
		floodFill(img);
	}*/

	public void floodFill(BufferedImage img) {
		int replacementColor = hashClr2;
		
		for ( int i = Math.max(x + 1, 0); i < Math.min(x + L, Canvas.width); i ++ ) {
			for ( int j = Math.max(y + 1, 0); j < Math.min(y + H, Canvas.height); j ++ ) {
				img.setRGB(i, j, replacementColor);
			}
		}
	}
}
