package shapes;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import main.Visitable;

import main.Draw;
import support.*;

public class Circle implements Visitable {
	public int xc, yc, R;
	public int hashClr1, hashClr2;
	
	int P, D ,X, Y, Q;
	public Circle(int xc, int yc, int R, int hashClr1, int hashClr2) {
		super();
		this.xc = xc;
		this.yc = yc;
		this.R = R;
		this.hashClr1 = hashClr1;
		this.hashClr2 = hashClr2;
		System.out.println(xc + "," + yc +"," + R);
		P = 0; Q = R;
		D = 3 - 2 * R;
		X = xc; Y = yc;
		System.out.println("aici e " + hashClr1);
	}
	
	public void accept (Draw specificShape) {
		specificShape.draw(this);
	}
	/*public void draw (BufferedImage img) {
		this.bresenham_alg(img);
		floodFill(img);
	*/
	
	public boolean allowedToSet (int x, int y) {
		if ( ( x >= 0 && x < Canvas.width ) && ( y >= 0 && y < Canvas.height ) ) {
			return true;
		}
		return false;
	}
	
	public void bresenham_alg (BufferedImage img) {
		
		if ( P == 0 ) {
			if (allowedToSet(X + Q, Y))
				img.setRGB(X + Q, Y, hashClr1);
			if (allowedToSet(X - Q, Y))
				img.setRGB(X - Q, Y, hashClr1);
			if (allowedToSet(X, Y + Q))
				img.setRGB(X, Y + Q, hashClr1);
			if (allowedToSet(X, Y - Q))
				img.setRGB(X, Y - Q, hashClr1);
		}
		
		P ++;
		if ( D < 0 ) {
			D += 4 * P + 6;
		}
		else {
			Q --;
			D += 4 * (P - Q) + 10;
		}
		
		drawCircleMeth (X, Y, P, Q, img, hashClr1);
		System.out.println(X + " " + Y + " " + P + " " + Q);
		
		if ( P < Q ) {
			bresenham_alg (img);
		}
		
	}
	
	public void drawCircleMeth (int X, int Y, int P, int Q, BufferedImage img, int hashClr1) {
		if (allowedToSet(X + P, Y + Q))
			img.setRGB(X + P, Y + Q, hashClr1);
		if (allowedToSet(X - P, Y + Q))
			img.setRGB(X - P, Y + Q, hashClr1);
		if (allowedToSet(X + P, Y - Q))
			img.setRGB(X + P, Y - Q, hashClr1);
		if (allowedToSet(X - P, Y - Q))
			img.setRGB(X - P, Y - Q, hashClr1);
		if (allowedToSet(X + Q, Y + P))
			img.setRGB(X + Q, Y + P, hashClr1);
		if (allowedToSet(X - Q, Y + P))
			img.setRGB(X - Q, Y + P, hashClr1);
		if (allowedToSet(X + Q, Y - P))
			img.setRGB(X + Q, Y - P, hashClr1);
		if (allowedToSet(X - Q, Y - P))
			img.setRGB(X - Q, Y - P, hashClr1);
		System.out.println((X + P) + "," + (X - P) + "," + (Y + P) + "," + (Y - P) + "," + (X + Q) + "," + (X - Q) + "," + (Y + Q) + "," + (Y - Q));
	}


	public Position calculateCentroid() {
		return new Position(xc, yc);
	}
	
	public void floodFill (BufferedImage img) {
		Position centralPos = calculateCentroid();
		int replacementColor = hashClr2, boundColor = hashClr1;
		
		List<Pixel> pixels = new ArrayList<Pixel>();
		pixels.add(new Pixel(centralPos, 4));
		ListIterator<Pixel> it = pixels.listIterator();
		System.out.println(replacementColor + " repl");
		
		while(it.hasNext()) {
			Pixel px = it.next();
			
			img.setRGB(px.pos.x, px.pos.y, replacementColor);
			if ( px.pos.x >= 1 )
			if (img.getRGB(px.pos.x - 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x - 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x - 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y >= 1 )
			if (img.getRGB(px.pos.x, px.pos.y - 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y - 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y - 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.x < Canvas.width - 1)
			if (img.getRGB(px.pos.x + 1, px.pos.y) != replacementColor && img.getRGB(px.pos.x + 1, px.pos.y) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x + 1, px.pos.y), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.pos.y < Canvas.height - 1)
			if (img.getRGB(px.pos.x, px.pos.y + 1) != replacementColor && img.getRGB(px.pos.x, px.pos.y + 1) != boundColor) {
				it.add(new Pixel(new Position(px.pos.x, px.pos.y + 1), 4));
				px.fillNearby --;
				it.previous();
			}
			if ( px.fillNearby == 0 ) {
				it.previous();
				it.next();
				it.remove();
			}
		}
	}
	
}
